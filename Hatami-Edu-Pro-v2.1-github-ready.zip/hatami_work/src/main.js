const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

let win;
const defaults = () => ({ sessions: [], tests: [], resources: [], goals: {}, settings: { theme: 'dark', focusLock: true, goal: 360, negativeMarking: true } });
const dataFile = () => path.join(app.getPath('userData'), 'hatami-pro.json');

function normalize(data) {
  const base = defaults();
  if (!data || typeof data !== 'object') return base;
  return {
    sessions: Array.isArray(data.sessions) ? data.sessions.filter(x => x && typeof x === 'object') : [],
    tests: Array.isArray(data.tests) ? data.tests.filter(x => x && typeof x === 'object') : [],
    resources: Array.isArray(data.resources) ? data.resources : [],
    goals: data.goals && typeof data.goals === 'object' ? data.goals : {},
    settings: { ...base.settings, ...(data.settings && typeof data.settings === 'object' ? data.settings : {}) }
  };
}

function load() {
  try { return normalize(JSON.parse(fs.readFileSync(dataFile(), 'utf8'))); }
  catch { return defaults(); }
}

function save(data) {
  const dir = path.dirname(dataFile());
  fs.mkdirSync(dir, { recursive: true });
  const target = dataFile();
  const tmp = `${target}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(normalize(data), null, 2), 'utf8');
  fs.renameSync(tmp, target);
  return true;
}

function create() {
  win = new BrowserWindow({
    width: 1500, height: 950, minWidth: 1100, minHeight: 700,
    backgroundColor: '#080d18', show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.once('ready-to-show', () => win.show());
}

app.whenReady().then(create);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('data:load', () => load());
ipcMain.handle('data:save', (_, data) => save(data));

ipcMain.handle('file:open', async (_, type) => {
  const filters = type === 'pdf'
    ? [{ name: 'PDF', extensions: ['pdf'] }]
    : [{ name: 'Video', extensions: ['mp4', 'webm', 'mkv', 'mov', 'avi', 'm4v'] }];
  const result = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
  return result.canceled || !result.filePaths[0] ? null : pathToFileURL(result.filePaths[0]).href;
});

ipcMain.handle('focus:set', (_, locked) => {
  if (!win) return false;
  if (locked) {
    win.setFullScreen(true);
    win.setAlwaysOnTop(true, 'floating');
    win.setKiosk(true);
  } else {
    win.setKiosk(false);
    win.setAlwaysOnTop(false);
    win.setFullScreen(false);
  }
  return true;
});

ipcMain.handle('focus:emergency', () => {
  if (!win) return false;
  win.setKiosk(false);
  win.setAlwaysOnTop(false);
  win.setFullScreen(false);
  return true;
});
