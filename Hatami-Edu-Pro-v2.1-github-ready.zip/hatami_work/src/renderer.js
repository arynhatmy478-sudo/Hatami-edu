const SUBJECTS = [
  'زیست | کنکور','شیمی | کنکور','ریاضی | کنکور','فیزیک | کنکور','دینی','پارسی','انگلیسی','عربی',
  'سلامت و بهداشت','هویت اجتماعی','زیست | نهایی','فیزیک | نهایی','شیمی | نهایی','ریاضی | نهایی','زمین شناسی'
];
const DEFAULTS = { sessions: [], tests: [], resources: [], goals: {}, settings: { theme: 'dark', focusLock: true, goal: 360, negativeMarking: true } };
let d = structuredClone(DEFAULTS);
let running = false, left = 1500, elapsed = 0, timer = null, lastTick = 0;
const $ = id => document.getElementById(id);
const fa = n => Number(n || 0).toLocaleString('fa-IR');
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const dateKey = x => { const z = new Date(x); return `${z.getFullYear()}-${String(z.getMonth()+1).padStart(2,'0')}-${String(z.getDate()).padStart(2,'0')}`; };
const todayKey = () => dateKey(new Date());
const dayDiff = (a,b) => Math.round((new Date(`${a}T00:00:00`) - new Date(`${b}T00:00:00`))/86400000);
const isValidDate = x => x && !Number.isNaN(new Date(x).getTime());

async function init() {
  d = await window.hatami.loadData() || structuredClone(DEFAULTS);
  d = { ...structuredClone(DEFAULTS), ...d, settings: { ...DEFAULTS.settings, ...(d.settings || {}) } };
  applyTheme(); fill(); bind(); render();
  $('date').textContent = new Date().toLocaleDateString('fa-IR', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  left = (Number($('duration').value) || 25) * 60; showTime();
}

function fill() {
  ['focusSub','testSub','planSub'].forEach(id => { if ($(id)) $(id).innerHTML = SUBJECTS.map(s => `<option>${escapeHtml(s)}</option>`).join(''); });
  $('subjects').innerHTML = SUBJECTS.map((s,i) => {
    const m = studyMinutes(s), tests = testCount(s), pct = subjectAverage(s);
    return `<div class="subject"><h3>${escapeHtml(s)}</h3><p>امروز: ${fa(studyMinutesToday(s))} دقیقه • ${fa(tests)} تست • ${fa(pct.toFixed(1))}٪</p><button class="secondary" data-plus="${i}">+ ۳۰ دقیقه</button></div>`;
  }).join('');
  document.querySelectorAll('[data-plus]').forEach(b => b.onclick = () => addStudy(SUBJECTS[+b.dataset.plus], 30, 'ثبت دستی'));
}

function bind() {
  document.querySelectorAll('.nav').forEach(b => b.onclick = () => page(b.dataset.page));
  document.querySelectorAll('[data-goto]').forEach(b => b.onclick = () => page(b.dataset.goto));
  $('theme').onclick = () => { d.settings.theme = d.settings.theme === 'dark' ? 'light' : 'dark'; save(); applyTheme(); };
  $('timerBtn').onclick = toggle;
  $('reset').onclick = () => reset(true);
  $('duration').onchange = () => { if (!running) { left = (Number($('duration').value)||25)*60; elapsed=0; showTime(); } };
  $('lock').onchange = () => { d.settings.focusLock = $('lock').checked; save(); };
  $('exitLock').onclick = async () => { await window.hatami.emergency(); $('exitLock').classList.add('hidden'); $('lock').checked = false; d.settings.focusLock=false; save(); };
  ['total','correct','wrong','blank'].forEach(id => $(id).oninput = validateTestInputs);
  $('negativeMarking').onchange = () => { d.settings.negativeMarking = $('negativeMarking').checked; save(); updateTestPercent(); };
  $('saveTest').onclick = saveTest;
  $('clearTests').onclick = () => { if (confirm('تمام جلسات تست حذف شوند؟')) { d.tests=[]; save(); render(); toast('تاریخچه تست پاک شد'); } };
  $('newTest').onclick = () => { page('tests'); $('topic').focus(); };
  $('pdfOpen').onclick = async () => { const url=await window.hatami.openFile('pdf'); if(url) $('pdfViewer').innerHTML=`<embed src="${url}" type="application/pdf">`; };
  $('videoOpen').onclick = async () => { const url=await window.hatami.openFile('video'); if(url){ $('player').src=url; $('player').play().catch(()=>{}); } };
  $('dailyGoal').value = d.settings.goal || 360;
  $('negativeMarking').checked = d.settings.negativeMarking !== false;
  $('saveSettings').onclick = () => { d.settings.goal = clamp(Number($('dailyGoal').value)||360, 1, 1440); save(); render(); toast('تنظیمات ذخیره شد ✓'); };
  $('resetData').onclick = () => { if(confirm('همه اطلاعات، برنامه‌ها و تاریخچه حذف شود؟')) { d=structuredClone(DEFAULTS); save(); render(); toast('اطلاعات حذف شد'); } };
  $('addPlan').onclick = addPlan;
  $('planMinutes').onkeydown = e => { if(e.key==='Enter') addPlan(); };
}

function page(id) {
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('on'));
  $(id).classList.add('on');
  document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===id));
  $('title').textContent={dashboard:'داشبورد',focus:'تمرکز',study:'مطالعه',tests:'تست‌ها',resources:'منابع',calendar:'تقویم',stats:'آمار',settings:'تنظیمات'}[id] || 'Hatami Edu Pro';
}
function applyTheme(){ document.body.classList.toggle('light', d.settings.theme==='light'); $('theme').textContent=d.settings.theme==='dark'?'☀️':'🌙'; }
function studyMinutes(s){ return d.sessions.filter(x=>x.subject===s).reduce((a,x)=>a+Number(x.minutes||0),0); }
function studyMinutesToday(s){ return d.sessions.filter(x=>x.subject===s && dateKey(x.date)===todayKey()).reduce((a,x)=>a+Number(x.minutes||0),0); }
function testCount(s){ return d.tests.filter(x=>x.subject===s).reduce((a,x)=>a+Number(x.total||0),0); }
function todayStudy(){ return d.sessions.filter(x=>dateKey(x.date)===todayKey()).reduce((a,x)=>a+Number(x.minutes||0),0); }
function todayTests(){ return d.tests.filter(x=>dateKey(x.date)===todayKey()).reduce((a,x)=>a+Number(x.total||0),0); }
function percentRaw(t,c){ return t ? (c/t)*100 : 0; }
function percentNegative(t,c,w){ return t ? ((c*3-w)/(t*3))*100 : 0; }
function effectivePercent(x){ return x.percentType==='negative' ? Number(x.percentNegative ?? x.percent ?? 0) : Number(x.percentRaw ?? x.percent ?? 0); }
function subjectAverage(s){ const a=d.tests.filter(x=>x.subject===s).map(effectivePercent); return a.length?a.reduce((a,b)=>a+b,0)/a.length:0; }
function validateTestInputs(){
  const t=Math.max(0,Number($('total').value)||0),c=Math.max(0,Number($('correct').value)||0),w=Math.max(0,Number($('wrong').value)||0),b=Math.max(0,Number($('blank').value)||0);
  $('testWarning').textContent = c+w+b>t ? 'جمع درست، غلط و نزده نباید از کل بیشتر باشد.' : '';
  updateTestPercent();
}
function updateTestPercent(){
  const t=Number($('total').value)||0,c=Number($('correct').value)||0,w=Number($('wrong').value)||0;
  const raw=percentRaw(t,c), neg=percentNegative(t,c,w);
  $('percent').textContent=fa(raw.toFixed(1))+'٪'; $('percentNegative').textContent=fa(neg.toFixed(1))+'٪';
}
function saveTest(){
  const total=Number($('total').value)||0,c=Number($('correct').value)||0,w=Number($('wrong').value)||0,b=Number($('blank').value)||0;
  if(!total)return toast('تعداد کل تست را وارد کن');
  if(c<0||w<0||b<0||c+w+b>total)return toast('مقادیر تست را بررسی کن');
  const raw=percentRaw(total,c), neg=percentNegative(total,c,w), useNeg=d.settings.negativeMarking!==false;
  d.tests.unshift({date:new Date().toISOString(),subject:$('testSub').value,topic:$('topic').value.trim()||'بدون مبحث',total,correct:c,wrong:w,blank:b,percent:useNeg?neg:raw,percentRaw:raw,percentNegative:neg,percentType:useNeg?'negative':'raw'});
  save(); render(); toast('جلسه تست ثبت شد ✓');
  ['topic','total','correct','wrong','blank'].forEach(id=>{ if($(id)) $(id).value=id==='total'?20:0; }); validateTestInputs();
}
function addStudy(subject,minutes,source='تمرکز'){
  minutes=Number(minutes)||0;if(minutes<=0)return;
  d.sessions.push({date:new Date().toISOString(),subject,minutes:Math.round(minutes*10)/10,source}); save(); render(); toast(`${fa(minutes)} دقیقه مطالعه ثبت شد ✓`);
}

async function toggle(){
  if(running){ clearInterval(timer); running=false; $('timerBtn').textContent='ادامه'; $('focusState').textContent='متوقف شده'; return; }
  if(left<=0) left=(Number($('duration').value)||25)*60;
  running=true; lastTick=Date.now(); $('timerBtn').textContent='توقف'; $('focusState').textContent='در حال مطالعه...';
  if($('lock').checked){ await window.hatami.setFocusLock(true); $('exitLock').classList.remove('hidden'); }
  timer=setInterval(()=>{ const now=Date.now(); const delta=Math.max(0,Math.min(5,Math.round((now-lastTick)/1000))); lastTick=now; if(!delta)return; left=Math.max(0,left-delta); elapsed+=delta; showTime(); if(left<=0) finish(); },500);
}
async function finish(){
  clearInterval(timer); running=false;
  const minutes=Math.round((Number($('duration').value||25))*10)/10;
  addStudy($('focusSub').value,minutes,'تمرکز کامل');
  $('treeBig').textContent='🌳'; $('focusState').textContent='جلسه کامل شد 🎉'; $('timerBtn').textContent='شروع';
  await window.hatami.emergency(); $('exitLock').classList.add('hidden'); clearInterval(timer); running=false; elapsed=0; left=(Number($('duration').value)||25)*60; showTime();
}
function reset(hard=true){ clearInterval(timer); if(hard && elapsed>=60){ addStudy($('focusSub').value, Math.round((elapsed/60)*10)/10, 'تمرکز نیمه‌تمام'); } running=false; elapsed=0; left=(Number($('duration').value)||25)*60; showTime(); $('timerBtn').textContent='شروع'; $('focusState').textContent='آماده شروع'; if(hard) window.hatami.emergency(); }
function showTime(){ const m=Math.floor(left/60),s=left%60; $('timer').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; }

function streak(){
  const active=new Set([...d.sessions.map(x=>dateKey(x.date)),...d.tests.map(x=>dateKey(x.date))]);
  let cur=new Date(); cur.setHours(0,0,0,0); let count=0;
  if(!active.has(dateKey(cur))){cur.setDate(cur.getDate()-1);}
  while(active.has(dateKey(cur))){count++;cur.setDate(cur.getDate()-1);}
  return count;
}
function statsForDay(key){
  const sessions=d.sessions.filter(x=>dateKey(x.date)===key); const tests=d.tests.filter(x=>dateKey(x.date)===key);
  const minutes=sessions.reduce((a,x)=>a+Number(x.minutes||0),0); const total=tests.reduce((a,x)=>a+Number(x.total||0),0);
  const avg=tests.length?tests.reduce((a,x)=>a+effectivePercent(x),0)/tests.length:0;
  return {minutes,total,avg,tests,sessions};
}
function render(){
  fill();
  const st=todayStudy(),tt=todayTests(),tests=d.tests.map(effectivePercent),avg=tests.length?tests.reduce((a,x)=>a+x,0)/tests.length:0,goal=d.settings.goal||360,pc=Math.min(100,Math.round(st/goal*100));
  $('mStudy').textContent=`${fa(Math.floor(st/60))}:${String(st%60).padStart(2,'0')}`; $('mTests').textContent=fa(tt); $('mPercent').textContent=fa(avg.toFixed(1))+'٪'; $('mStreak').textContent=fa(streak())+' روز 🔥';
  $('goalText').textContent=`${fa(st)} / ${fa(goal)} دقیقه`; $('ring').textContent=fa(pc)+'٪'; $('forestIcon').textContent=st>=goal?'🌳':st>=goal/2?'🌲':'🌱'; $('treeBig').textContent=st>=goal?'🌳':st>=goal/2?'🌲':'🌱';
  $('sStudy').textContent=fa(d.sessions.reduce((a,x)=>a+Number(x.minutes||0),0))+' دقیقه'; $('sTests').textContent=fa(d.tests.reduce((a,x)=>a+Number(x.total||0),0)); $('sPercent').textContent=fa(avg.toFixed(1))+'٪'; $('sTrees').textContent=fa(d.sessions.filter(x=>Number(x.minutes)>=25).length); $('statsStreak').textContent=fa(streak())+' روز';
  $('recent').innerHTML=d.tests.slice(0,5).map(x=>`<div class="item"><b>📝 ${escapeHtml(x.subject)}</b>${escapeHtml(x.topic)}<br><small>${fa(x.total)} تست • خام ${fa(Number(x.percentRaw??x.percent).toFixed(1))}٪ • نمره ${fa(effectivePercent(x).toFixed(1))}٪</small></div>`).join('')||'<p class="hint">هنوز فعالیتی ثبت نشده.</p>';
  renderHistory(); renderStats(); renderCalendar(); renderPlans(); showTime(); validateTestInputs();
}
function renderHistory(){ $('testHistory').innerHTML=d.tests.map((x,i)=>`<div class="item"><b>${escapeHtml(x.subject)} — ${escapeHtml(x.topic)}</b><div>📝 ${fa(x.total)} | ✅ ${fa(x.correct)} | ❌ ${fa(x.wrong)} | ➖ ${fa(x.blank)}</div><div>🎯 خام: ${fa(Number(x.percentRaw??x.percent).toFixed(1))}٪ • ${x.percentType==='negative'?'با نمره منفی':'خام'}: ${fa(effectivePercent(x).toFixed(1))}٪</div><small>${isValidDate(x.date)?new Date(x.date).toLocaleString('fa-IR'):''}</small></div>`).join('')||'<p class="hint">هنوز تستی ثبت نشده.</p>'; }
function renderStats(){ const max=Math.max(1,...SUBJECTS.map(s=>studyMinutes(s))); $('subjectStats').innerHTML=SUBJECTS.map(s=>`<div class="rowStat"><b>${escapeHtml(s)}</b><div class="bar"><i style="width:${studyMinutes(s)/max*100}%"></i></div><span>${fa(studyMinutes(s))} دقیقه<br><small>${fa(subjectAverage(s).toFixed(1))}٪</small></span></div>`).join('');
  const week=[]; for(let i=6;i>=0;i--){const x=new Date();x.setDate(x.getDate()-i);week.push(statsForDay(dateKey(x)));} $('weekStudy').textContent=fa(week.reduce((a,x)=>a+x.minutes,0))+' دقیقه'; $('weekTests').textContent=fa(week.reduce((a,x)=>a+x.total,0)); $('weekAvg').textContent=fa((week.filter(x=>x.tests.length).reduce((a,x)=>a+x.avg,0)/Math.max(1,week.filter(x=>x.tests.length).length)).toFixed(1))+'٪';
}
function renderCalendar(){
  const now=new Date(),days=[]; for(let i=29;i>=0;i--){const x=new Date(now);x.setDate(now.getDate()-i);const k=dateKey(x),s=statsForDay(k);days.push(`<button class="day ${k===todayKey()?'today':''}" data-day="${k}"><b>${x.toLocaleDateString('fa-IR',{day:'numeric',month:'short'})}</b><span class="dot">📚 ${fa(s.minutes)} دقیقه<br>📝 ${fa(s.total)} تست</span></button>`);} $('calendarGrid').innerHTML=days.join(''); document.querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>showDay(b.dataset.day));
}
function showDay(k){const s=statsForDay(k),dte=new Date(`${k}T12:00:00`); $('dayDetails').innerHTML=`<b>${dte.toLocaleDateString('fa-IR',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</b><p>📚 ${fa(s.minutes)} دقیقه مطالعه • 📝 ${fa(s.total)} تست • 🎯 ${fa(s.avg.toFixed(1))}٪</p>`;}
function renderPlans(){const plans=Array.isArray(d.goals.today)?d.goals.today:[]; $('planList').innerHTML=plans.length?plans.map((p,i)=>`<div class="plan ${p.done?'done':''}"><label><input type="checkbox" data-plan="${i}" ${p.done?'checked':''}> <b>${escapeHtml(p.subject)}</b> — ${fa(p.minutes)} دقیقه</label><button class="miniDanger" data-delplan="${i}">حذف</button></div>`).join(''):'<p class="hint">برای امروز هنوز برنامه‌ای نساختی.</p>'; document.querySelectorAll('[data-plan]').forEach(c=>c.onchange=()=>{plans[+c.dataset.plan].done=c.checked;d.goals.today=plans;save();renderPlans();});document.querySelectorAll('[data-delplan]').forEach(b=>b.onclick=()=>{plans.splice(+b.dataset.delplan,1);d.goals.today=plans;save();renderPlans();});}
function addPlan(){const m=Math.max(1,Number($('planMinutes').value)||0);if(!m)return toast('زمان برنامه را وارد کن');const plans=Array.isArray(d.goals.today)?d.goals.today:[];plans.push({subject:$('planSub').value,minutes:m,done:false});d.goals.today=plans;save();renderPlans();$('planMinutes').value='';toast('به برنامه امروز اضافه شد ✓');}
function escapeHtml(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
async function save(){try{await window.hatami.saveData(d);}catch(e){toast('خطا در ذخیره اطلاعات');console.error(e);}}
function toast(t){const x=$('toast');x.textContent=t;x.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>x.classList.remove('show'),2200);}
init();
