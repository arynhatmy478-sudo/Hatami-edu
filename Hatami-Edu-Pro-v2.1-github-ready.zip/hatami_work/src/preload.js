const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('hatami', {
  loadData: () => ipcRenderer.invoke('data:load'),
  saveData: (data) => ipcRenderer.invoke('data:save', data),
  openFile: (type) => ipcRenderer.invoke('file:open', type),
  setFocusLock: (value) => ipcRenderer.invoke('focus:set', Boolean(value)),
  emergency: () => ipcRenderer.invoke('focus:emergency')
});
